from flask import Flask, render_template, request, redirect, url_for
import pymysql

pibd = Flask(__name__)

# Configurare conexiune la baza de date
DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "Polivivi6!",
    "database": "db1"
}

# Funcție pentru interogări la baza de date
def query_db(query, args=(), one=False):
    try:
        conn = pymysql.connect(
            host=DB_CONFIG['host'],
            user=DB_CONFIG['user'],
            password=DB_CONFIG['password'],
            database=DB_CONFIG['database']
        )
        cursor = conn.cursor(pymysql.cursors.DictCursor)
        cursor.execute(query, args)
        conn.commit()
        result = cursor.fetchall()
        cursor.close()
        conn.close()
        return (result[0] if result else None) if one else result
    except pymysql.MySQLError as err:
        print(f"Database error: {err}")
        return None


# Rute principale
@pibd.route('/')
def index():
    return render_template('index.html')


# Rutele pentru tabela Elevi
@pibd.route('/tabela_elevi')
def tabela_elevi():
    elevi = query_db('SELECT idelev, nume, prenume, clasa FROM elevi')
    return render_template('tabela_elevi.html', elevi=elevi)

@pibd.route('/adaugare_elev', methods=['GET', 'POST'])
def adaugare_elev():
    if request.method == 'POST':
        nume = request.form['nume']
        prenume = request.form['prenume']
        clasa = request.form['clasa']
        query_db('INSERT INTO elevi (nume, prenume, clasa) VALUES (%s, %s, %s)', (nume, prenume, clasa))
        return redirect(url_for('tabela_elevi'))
    return render_template('adaugare_elev.html')

@pibd.route('/modifica_elev/<int:idelev>', methods=['GET', 'POST'])
def modifica_elev(idelev):
    elev = query_db('SELECT * FROM elevi WHERE idelev = %s', (idelev,), one=True)
    if request.method == 'POST':
        nume = request.form['nume']
        prenume = request.form['prenume']
        clasa = request.form['clasa']
        query_db('UPDATE elevi SET nume = %s, prenume = %s, clasa = %s WHERE idelev = %s', (nume, prenume, clasa, idelev))
        return redirect(url_for('tabela_elevi'))
    return render_template('modifica_elev.html', elev=elev)

@pibd.route('/sterge_elev/<int:idelev>', methods=['GET', 'POST'])
def sterge_elev(idelev):
    if request.method == 'POST':
        # Execută ștergerea din baza de date
        query_db('DELETE FROM elevi WHERE idelev = %s', (idelev,))
        return redirect(url_for('tabela_elevi'))  # Redirecționare către tabela elevilor

    # Dacă este o cerere GET, afișează formularul de confirmare
    return render_template('sterge_elev.html', idelev=idelev)


# Rutele pentru tabela Profesori
@pibd.route('/tabela_profesori')
def tabela_profesori():
    profesori = query_db('''
        SELECT p.idprofesor, p.nume, p.prenume, p.materie, p.contact,
               s.nota AS nota, e.nume AS elev_nume, e.prenume AS elev_prenume
        FROM profesori p
        LEFT JOIN subiecte s ON p.idsubiect = s.idsubiect
        LEFT JOIN elevi e ON p.idelev = e.idelev
    ''')
    return render_template('tabela_profesori.html', profesori=profesori)



@pibd.route('/adaugare_profesor', methods=['GET', 'POST'])
def adaugare_profesor():
    if request.method == 'POST':
        idprofesor = request.form['idprofesor']
        nume = request.form['nume']
        prenume = request.form['prenume']
        materie = request.form['materie']
        contact = request.form['contact']
        idsubiect = request.form['idsubiect']
        idelev = request.form['idelev']

        try:
            # Asigură-te că toate câmpurile necesare sunt incluse
            query_db('INSERT INTO profesori (idprofesor, nume, prenume, materie, contact, idsubiect, idelev) VALUES (%s, %s, %s, %s, %s, %s, %s)', 
                     (idprofesor, nume, prenume, materie, contact, idsubiect, idelev))
            print(f"Profesorul {nume} {prenume} a fost adăugat cu succes!")
        except Exception as e:
            print(f"Eroare la adăugarea profesorului: {e}")
        
        return redirect(url_for('tabela_profesori'))

    subiecte = query_db('SELECT idsubiect, materie FROM subiecte')
    elevi = query_db('SELECT idelev, nume, prenume FROM elevi ORDER BY idelev')

    return render_template('adaugare_profesor.html', subiecte=subiecte, elevi=elevi)


@pibd.route('/sterge_profesor/<int:idprofesor>', methods=['GET', 'POST'])
def sterge_profesor(idprofesor):
    if request.method == 'POST':
        # Perform the deletion logic
        query_db('DELETE FROM profesori WHERE idprofesor = %s', (idprofesor,))
        return redirect(url_for('tabela_profesori'))
    return render_template('sterge_profesor.html', idprofesor=idprofesor)



# Rutele pentru tabela Subiecte
@pibd.route('/tabela_subiecte')
def tabela_subiecte():
    subiecte = query_db('SELECT * FROM subiecte')
    return render_template('tabela_subiecte.html', subiecte=subiecte)

# Ruta pentru adăugarea unui subiect
@pibd.route('/adaugare_subiect', methods=['GET', 'POST'])
def adaugare_subiect():
    if request.method == 'POST':
        # Preia datele din formular
        materie = request.form['materie']
        nota = request.form['nota']
        
        # Inseră datele în baza de date
        query_db('INSERT INTO subiecte (materie, nota) VALUES (%s, %s)', (materie, nota))
        
        # Redirecționează către tabela de subiecte
        return redirect(url_for('tabela_subiecte'))
    
    # În cazul unei cereri GET, returnează formularul pentru adăugarea unui subiect
    return render_template('adaugare_subiect.html')

# Ruta pentru modificarea unui subiect existent
@pibd.route('/modifica_subiect/<int:idsubiect>', methods=['GET', 'POST'])
def modifica_subiect(idsubiect):
    # Preia informațiile despre subiect
    subiect = query_db('SELECT * FROM subiecte WHERE idsubiect = %s', (idsubiect,), one=True)
    
    if request.method == 'POST':
        # Preia datele actualizate din formular
        materie = request.form['materie']
        nota = request.form['nota']
        
        # Actualizează datele în baza de date
        query_db('UPDATE subiecte SET materie = %s, nota = %s WHERE idsubiect = %s', (materie, nota, idsubiect))
        
        # Redirecționează către tabela de subiecte
        return redirect(url_for('tabela_subiecte'))
    
    # În cazul unei cereri GET, returnează formularul cu datele actuale ale subiectului
    return render_template('modifica_subiect.html', subiect=subiect)

if __name__ == '__main__':
    pibd.run(debug=True)
