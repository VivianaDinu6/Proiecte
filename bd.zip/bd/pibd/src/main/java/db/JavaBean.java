package db;

import java.sql.*;

public class JavaBean {
    String error;
    Connection con;

    // Constructorul clasei
    public JavaBean() {
    }

    // Conectare la baza de date
    public void connect() throws ClassNotFoundException, SQLException, Exception {
        try {
            // Încărcarea driverului JDBC
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Stabilirea conexiunii la baza de date
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db1?useSSL=false", "root", "Polivivi6!");
        } catch (ClassNotFoundException cnfe) {
            error = "ClassNotFoundException: Nu s-a găsit driverul bazei de date.";
            throw new ClassNotFoundException(error);
        } catch (SQLException sqle) {
            error = "SQLException: Nu se poate conecta la baza de date.";
            throw new SQLException(error);
        } catch (Exception e) {
            error = "Exception: A apărut o excepție neprevăzută în timp ce se stabilea legătura la baza de date.";
            throw new Exception(error);
        }
    }

    // Închiderea conexiunii la baza de date
    public void disconnect() throws SQLException {
        try {
            if (con != null) {
                con.close();
            }
        } catch (SQLException sqle) {
            error = "SQLException: Nu se poate închide conexiunea la baza de date.";
            throw new SQLException(error);
        }
    }

    // Metode pentru manipularea datelor în tabelul "elevi"
    public void adaugaElev(String nume, String prenume, int clasa) throws SQLException, Exception {
        if (con != null) {
            String query = "INSERT INTO db1.elevi (nume, prenume, clasa) VALUES (?, ?, ?)";
            try (PreparedStatement ps = con.prepareStatement(query)) {
                ps.setString(1, nume);
                ps.setString(2, prenume);
                ps.setInt(3, clasa);
                ps.executeUpdate();
            } catch (SQLException sqle) {
                error = "ExceptieSQL: Reactualizare nereușită; este posibil să existe duplicate.";
                throw new SQLException(error);
            }
        } else {
            error = "Exceptie: Conexiunea cu baza de date a fost pierdută.";
            throw new Exception(error);
        }
    }

    public void modificaElev(String nume, String prenume, int clasa, int idelev) throws SQLException, Exception {
        if (con != null) {
            String query = "UPDATE db1.elevi SET nume = ?, prenume = ?, clasa = ? WHERE idelev = ?";
            try (PreparedStatement ps = con.prepareStatement(query)) {
                ps.setString(1, nume);
                ps.setString(2, prenume);
                ps.setInt(3, clasa);
                ps.setInt(4, idelev);
                ps.executeUpdate();
            } catch (SQLException sqle) {
                error = "ExceptieSQL: Reactualizare nereușită.";
                throw new SQLException(error);
            }
        } else {
            error = "Exceptie: Conexiunea cu baza de date a fost pierdută.";
            throw new Exception(error);
        }
    }

    // Obținerea elevilor
    public ResultSet vedeElevi() throws SQLException, Exception {
        ResultSet rs = null;
        try {
            String queryString = "SELECT * FROM db1.elevi ORDER BY nume;";
            Statement stmt = con.createStatement();
            rs = stmt.executeQuery(queryString);
        } catch (SQLException sqle) {
            error = "SQLException: Interogarea nu a fost posibilă.";
            throw new SQLException(error);
        } catch (Exception e) {
            error = "A apărut o excepție în timp ce se extrăgeau datele.";
            throw new Exception(error);
        }
        return rs;
    }

    // Metode pentru manipularea datelor în tabelul "profesori"
    // Metode pentru manipularea datelor în tabelul "profesori"
    public boolean adaugaProfesor(int idprofesor, String nume, String prenume, String materie, String contact, int idelev, int idsubiect) throws SQLException, Exception {
        if (con != null) {
            String query = "INSERT INTO profesori (idprofesor, nume, prenume, materie, contact, idelev, idsubiect) VALUES (?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement ps = con.prepareStatement(query)) {
                ps.setInt(1, idprofesor);  // Setează ID-ul profesorului
                ps.setString(2, nume);      // Setează numele profesorului
                ps.setString(3, prenume);   // Setează prenumele profesorului
                ps.setString(4, materie);   // Setează materia predată
                ps.setString(5, contact);   // Setează contactul profesorului
                ps.setInt(6, idelev);       // Setează ID-ul elevului
                ps.setInt(7, idsubiect);    // Setează ID-ul subiectului

                int rowsAffected = ps.executeUpdate();  // Execută query-ul și obține numărul de rânduri afectate
                return rowsAffected > 0;  // Returnează true dacă s-a inserat un profesor
            } catch (SQLException sqle) {
                error = "ExceptieSQL: Adăugare profesor nereușită.";
                throw new SQLException(error);  // Aruncă excepție SQL în caz de eroare
            }
        } else {
            error = "Exceptie: Conexiunea cu baza de date a fost pierdută.";
            throw new Exception(error);  // Aruncă excepție dacă nu există conexiune la baza de date
        }
    }



    // Obținerea profesorilor
    public ResultSet vedeProfesori() throws SQLException, Exception {
        ResultSet rs = null;
        try {
            String queryString = "SELECT * FROM db1.profesori ORDER BY nume;";
            Statement stmt = con.createStatement();
            rs = stmt.executeQuery(queryString);
        } catch (SQLException sqle) {
            error = "SQLException: Interogarea nu a fost posibilă.";
            throw new SQLException(error);
        } catch (Exception e) {
            error = "A apărut o excepție în timp ce se extrăgeau datele.";
            throw new Exception(error);
        }
        return rs;
    }

    // Metode pentru manipularea datelor în tabelul "subiecte"
    public void adaugaSubiect(String materie, String nota) throws SQLException, Exception {
        if (con != null) {
            String query = "INSERT INTO db1.subiecte (materie, nota) VALUES (?, ?)";
            try (PreparedStatement ps = con.prepareStatement(query)) {
                ps.setString(1, materie);
                ps.setString(2, nota);
                ps.executeUpdate();
            } catch (SQLException sqle) {
                error = "ExceptieSQL: Adăugare subiect nereușită.";
                throw new SQLException(error);
            }
        } else {
            error = "Exceptie: Conexiunea cu baza de date a fost pierdută.";
            throw new Exception(error);
        }
    }


    // Obținerea subiectelor
    public ResultSet vedeSubiecte() throws SQLException, Exception {
        ResultSet rs = null;
        try {
            String queryString = "SELECT * FROM db1.subiecte ORDER BY materie ASC;";
            Statement stmt = con.createStatement();
            rs = stmt.executeQuery(queryString);
        } catch (SQLException sqle) {
            error = "SQLException: Interogarea nu a fost posibilă.";
            throw new SQLException(error);
        } catch (Exception e) {
            error = "A apărut o excepție în timp ce se extrăgeau datele.";
            throw new Exception(error);
        }
        return rs;
    }

    // Ștergere elev după ID
    public boolean stergeElev(int idelev) throws SQLException {
        String query = "DELETE FROM elevi WHERE idelev = ?";
        try (PreparedStatement ps = con.prepareStatement(query)) {
            ps.setInt(1, idelev);
            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            error = "Eroare la ștergerea elevului.";
            throw e;
        }
    }

    // Ștergere profesor după ID
    public boolean stergeProfesor(int idprofesor) throws SQLException, Exception {
        if (con != null) {
            String query = "DELETE FROM profesori WHERE idprofesor = ?";
            try (PreparedStatement ps = con.prepareStatement(query)) {
                ps.setInt(1, idprofesor);
                int rowsAffected = ps.executeUpdate();
                return rowsAffected > 0;
            } catch (SQLException sqle) {
                error = "ExceptieSQL: Ștergere profesor nereușită.";
                throw new SQLException(error);
            }
        } else {
            error = "Exceptie: Conexiunea cu baza de date a fost pierdută.";
            throw new Exception(error);
        }
    }



    public void modificaSubiect(int idsubiect, String materie, String nota) throws SQLException, Exception {
        if (con != null) {
            String query = "UPDATE db1.subiecte SET materie = ?, nota = ? WHERE idsubiect = ?";
            try (PreparedStatement ps = con.prepareStatement(query)) {
                ps.setString(1, materie);
                ps.setString(2, nota);
                ps.setInt(3, idsubiect);
                ps.executeUpdate();
            } catch (SQLException sqle) {
                error = "ExceptieSQL: Modificare subiect nereușită.";
                throw new SQLException(error);
            }
        } else {
            error = "Exceptie: Conexiunea cu baza de date a fost pierdută.";
            throw new Exception(error);
        }
    }
}